const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags, SeparatorSpacingSize } = require('../utils/componentBuilders.js');
const moderationDb = require('../database/moderationDb.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('kick')
        .setDescription('Kick a user from the server')
        .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
        .addUserOption(option =>
            option.setName('user')
                .setDescription('User to kick')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for the kick')
                .setRequired(false)
        ),
    async execute(interaction) {
        const targetUser = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason') || 'No reason provided';

        const container = new ContainerBuilder().setAccentColor(0xFF0000); // Red

        try {
            const member = await interaction.guild.members.fetch(targetUser.id);

            // Hierarchy check
            if (member.roles.highest.position >= interaction.member.roles.highest.position && interaction.user.id !== interaction.guild.ownerId) {
                container.addTextDisplayComponents(td => td.setContent(`# ❌ Hierarchy Error`));
                container.addTextDisplayComponents(td => td.setContent(`You cannot kick ${targetUser} because their role is equal or higher than yours.`));
                return interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2, ephemeral: true });
            }

            if (!member.kickable) {
                container.addTextDisplayComponents(td => td.setContent(`# ❌ Permission Error`));
                container.addTextDisplayComponents(td => td.setContent(`I cannot kick ${targetUser}. Is my role high enough?`));
                return interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2, ephemeral: true });
            }

            // DM User
            try {
                // Using standard embed for DM as Components V2 might not be fully supported in DMs or we prefer standard for user notifications
                // But the user policy says "NO EmbedBuilder"? 
                // "UI: NO EmbedBuilder" applies to the Bot's responses in channels.
                // It's safer to use V2 for DMs too if supported, or just text.
                // However, DMs often don't support new experimental features.
                // Let's stick to simple text for DM to be safe.
                await targetUser.send(`**You have been kicked from ${interaction.guild.name}**\nReason: ${reason}`);
            } catch (e) {
                // ignore DM fail
            }

            await member.kick(reason);

            // Log to DB
            moderationDb.addAction(interaction.guild.id, {
                type: 'kick',
                userId: targetUser.id,
                moderator: { id: interaction.user.id, username: interaction.user.username },
                reason: reason
            });

            container.addTextDisplayComponents(td => td.setContent(`# 👢 User Kicked`));
            container.addSeparatorComponents(sep => sep.setSpacing(SeparatorSpacingSize.Small));
            container.addTextDisplayComponents(td => td.setContent(`**User:** ${targetUser}\n**Reason:** ${reason}`));
            container.addTextDisplayComponents(td => td.setContent('**UnderFive Studios** • Premium Plugins Under $5'));

            await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });

        } catch (error) {
            console.error(error);
            container.addTextDisplayComponents(td => td.setContent(`# ❌ Error`));
            if (error.code === 10007) {
                container.addTextDisplayComponents(td => td.setContent(`User not found in server.`));
            } else {
                container.addTextDisplayComponents(td => td.setContent(`An error occurred: ${error.message}`));
            }
            await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2, ephemeral: true });
        }
    }
};
