const { SlashCommandBuilder } = require('discord.js');
const { ContainerBuilder, SectionBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags, SeparatorSpacingSize } = require('../utils/componentBuilders.js');
const inviteDb = require('../database/inviteDb.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('invites')
        .setDescription('View invite statistics')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('User to view invites for')
                .setRequired(false)
        ),
    async execute(interaction) {
        const targetUser = interaction.options.getUser('user') || interaction.user;
        const guildId = interaction.guild.id;

        // Simulating data since we don't have a live tracking system constantly updating this specific DB yet
        // In a real scenario, an InviteTracker service would update inviteDb
        let inviteData = inviteDb.getUserInvites(guildId, targetUser.id);

        if (!inviteData) {
            inviteData = {
                total: 0,
                regular: 0,
                left: 0,
                fake: 0,
                bonus: 0
            };
        }

        const container = new ContainerBuilder()
            .setAccentColor(0x5865F2); // Blurple

        container.addTextDisplayComponents(td =>
            td.setContent(`# 📨 Invite Stats`)
        );

        container.addSeparatorComponents(sep => sep.setSpacing(SeparatorSpacingSize.Small));

        const statsText = [
            `**User:** ${targetUser}`,
            '',
            `📨 **Total Invites:** ${inviteData.total}`,
            `✅ **Regular:** ${inviteData.regular}`,
            `👋 **Left:** ${inviteData.left}`,
            `🚫 **Fake:** ${inviteData.fake}`,
            `🎁 **Bonus:** ${inviteData.bonus}`
        ].join('\n');

        container.addSectionComponents(section => {
            section.addTextDisplayComponents(td => td.setContent(statsText));
            section.setThumbnailAccessory(thumb => thumb.setURL(targetUser.displayAvatarURL({ dynamic: true })));
        });

        const footer = new TextDisplayBuilder().setContent('**UnderFive Studios** • Premium Plugins Under $5');
        container.addTextDisplayComponents(footer);

        await interaction.reply({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
};
