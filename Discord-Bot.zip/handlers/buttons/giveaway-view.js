const giveawayDb = require('../../database/giveawayDb');
const EMOJIS = require('../../utils/emojis');
const { MessageFlags } = require('discord.js');

const SAFE_MENTIONS = { parse: [] };

module.exports = {
    // Match pattern: giveaway_view:<giveawayId>
    customId: 'giveaway_view',

    // Check if this handler should handle the interaction
    match(customId) {
        return customId.startsWith('giveaway_view:');
    },

    async execute(interaction) {
        try {
            const [, giveawayId] = interaction.customId.match(/^giveaway_view:([\w_-]+)$/) || [];

            if (!giveawayId) {
                return interaction.reply({
                    content: `${EMOJIS.error} Invalid giveaway button.`,
                    flags: MessageFlags.Ephemeral
                });
            }

            const giveaway = giveawayDb.getGiveawayById(interaction.guildId, giveawayId);

            if (!giveaway) {
                return interaction.reply({
                    content: `${EMOJIS.error} Giveaway not found.`,
                    flags: MessageFlags.Ephemeral
                });
            }

            const entries = giveaway.entries || [];

            if (entries.length === 0) {
                return interaction.reply({
                    content: `${EMOJIS.giveawayarrow || '➡️'} No participants yet.`,
                    flags: MessageFlags.Ephemeral
                });
            }

            // Show up to 25 participants
            const preview = entries.slice(0, 25).map((id, i) => `${i + 1}. <@${id}>`).join('\n');
            const more = entries.length > 25 ? `\n...and ${entries.length - 25} more` : '';

            return interaction.reply({
                content: `${EMOJIS.giveawayarrow || '➡️'} **Participants (${entries.length}):**\n${preview}${more}`,
                flags: MessageFlags.Ephemeral,
                allowedMentions: SAFE_MENTIONS
            });

        } catch (err) {
            console.error('[giveaway_view] failed:', err);
            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({
                    content: `${EMOJIS.error} Unable to fetch participants right now.`,
                    flags: MessageFlags.Ephemeral
                }).catch(() => { });
            }
        }
    }
};
